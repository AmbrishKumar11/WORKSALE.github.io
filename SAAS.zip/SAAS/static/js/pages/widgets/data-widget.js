'use strict';
$(document).ready(function () {
	$('.assign-style').slimscroll({
		height: '449px',
		size: '5px'
	});
	$('.media-list').slimscroll({
		height: '405px',
		size: '5px'
	});
	$('#chat-conversation').slimscroll({
		height: '277px',
		size: '5px'
	});
	$('.table-assign-task').slimscroll({
		height: '440px',
		size: '5px'
	});

});
