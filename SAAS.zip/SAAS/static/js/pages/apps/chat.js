'use strict';
$(function () {
	$('#chat_user').slimscroll({
		height: '590px',
		size: '5px'
	});
});

$(function () {
	$('#chat-conversation').slimscroll({
		height: '449px',
		size: '5px'
	});
});